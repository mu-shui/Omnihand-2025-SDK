"""
OmniHand Pro 2025 (O12) Solver Module
"""

from ..omnihand_core import OmniHandPro2025Solver

__all__ = ['OmniHandPro2025Solver']
